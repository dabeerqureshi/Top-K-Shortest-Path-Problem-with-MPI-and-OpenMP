#include <stdio.h>             
#include <stdlib.h>           
#include <mpi.h>               
#include <time.h>              
#include <omp.h>               

#define MAX_NODES 1000         // Defining maximum number of nodes in the graph
#define INF 9999999            // Defining infinity value for distances
// Define a structure for graph edges
struct Edge {                  
    int destination;           // Destination node of the edge
    int weight;                // Weight of the edge
    struct Edge* next;         // Pointer to the next edge
};
// Defining a structure for graph nodes
struct Node {                  
    struct Edge* head;         // Pointer to the first edge of the node
};
// Defining a structure for shortest paths
struct Path {                  
    int node;                  // Node in the path
    int distance;              // Distance of the path
};
// Defining a structure for priority queue
struct PriorityQueue {         
    struct Path *paths;        // Array of paths
    int size;                  // Current size of the queue
    int capacity;              // Capacity of the queue
};
// Function to compare paths for sorting
int comparePaths(const void *a, const void *b) 
{  
    const struct Path *pathA = (const struct Path *)a;  // Converting pointer to Path structure
    const struct Path *pathB = (const struct Path *)b;  // Converting pointer to Path structure
    return (pathA->distance - pathB->distance);  // Comparing distances of paths
}
// Function to initialize priority queue
void initPriorityQueue(struct PriorityQueue *pq, int capacity) 
{  
    pq->paths = (struct Path *)malloc(capacity * sizeof(struct Path));  // Allocating memory for paths
    // Checking if memory allocation failed
    if (pq->paths == NULL) {  
        fprintf(stderr, "Memory allocation failed\n");  // Print error message
        exit(EXIT_FAILURE);  // Exit program with failure status
    }
    pq->size = 0;  // Initializing size of the queue
    pq->capacity = capacity;  // Setting capacity of the queue
}
// Function to insert a path into the priority queue
void insert(struct PriorityQueue *pq, struct Path path) 
{  
    // Checking if queue has space
    if (pq->size < pq->capacity) 
    {  
        int i = pq->size - 1;  // Starting from the end of the queue
        while (i >= 0 && pq->paths[i].distance > path.distance) {  // Finding the correct position for insertion
            pq->paths[i + 1] = pq->paths[i];  // Shifting elements to make space for insertion
            i--;  // Move to the previous position
        }
        pq->paths[i + 1] = path;  // Inserting the path at the correct position
        pq->size++;  // Increment the size of the queue
    } 
     // Checking if queue is not empty and path has smaller distance than the last element
    else if (pq->size > 0 && path.distance < pq->paths[pq->size - 1].distance) 
    { 
        int i = pq->size - 2;  // Starting from the second last element
        while (i >= 0 && pq->paths[i].distance > path.distance) {  // Finding the correct position for insertion
            pq->paths[i + 1] = pq->paths[i];  // Shifting elements to make space for insertion
            i--;  // Moving to the previous position
        }
        pq->paths[i + 1] = path;  // Insert the path at the correct position
    }
}
// Function to free memory allocated for priority queue
void freePriorityQueue(struct PriorityQueue *pq) 
{  
    free(pq->paths);  // Free memory allocated for paths
}
// Function to read graph from file
int readGraphFromFile(const char *filename, struct Node graph[], int *num_nodes, int *num_edges) 
{
  
    FILE *file = fopen(filename, "r");  // Open file in read mode
    if (file == NULL) {  // Checking if file opening failed
        fprintf(stderr, "Error opening file %s\n", filename);  // Print error message
        return 0;  // Return failure status
    }

    if (fscanf(file, "%d", num_nodes) != 1) {  // Reading number of nodes from file
        fprintf(stderr, "Error reading number of nodes from file\n");  // Print error message
        fclose(file);  // Close file
        return 0;  // Return failure status
    }

    for (int i = 0; i < *num_nodes; i++) {  // Initializing graph nodes
        graph[i].head = NULL;  // Set head of each node to NULL
    }

    *num_edges = 0;  // Initializing number of edges

    int source, destination, weight;  // Variables to store edge information
    while (fscanf(file, "%d %d %d", &source, &destination, &weight) == 3) {  // Reading edge information from file
        struct Edge* new_edge = (struct Edge*)malloc(sizeof(struct Edge));  // Allocate memory for new edge
        if (new_edge == NULL) {  // Check if memory allocation failed
            fprintf(stderr, "Memory allocation failed\n");  // Print error message
            fclose(file);  // Close file
            return 0;  // Return failure status
        }
        new_edge->destination = destination;  // Setting destination of the edge
        new_edge->weight = weight;  // Setting weight of the edge
        new_edge->next = graph[source].head;  // Adding edge to the linked list of the source node
        graph[source].head = new_edge;  // Updating head of the source node
        (*num_edges)++;  // Increment number of edges
    }

    fclose(file);  // Close file
    return 1;  // Return success status
}
// Function to perform Dijkstra's algorithm
void dijkstra(int source, int num_nodes, struct Node graph[], struct PriorityQueue paths[], int K, int rank) 
{  
    int visited[MAX_NODES] = {0};  // Array to keep track of visited nodes
    int dist[MAX_NODES];  // Array to store distances from source node
    int parent[MAX_NODES];  // Array to store parent nodes in the shortest paths
    // Initializing distances and parent nodes
    for (int i = 0; i < num_nodes; i++) 
    {  
        dist[i] = INF;  // Setting distances to infinity
        parent[i] = -1;  // Setting parent nodes to -1 (invalid)
    }

    dist[source] = 0;  // Setting distance of source node to 0

    int remaining_nodes = num_nodes;  // Initializing remaining nodes to number of nodes
    // Repeating until all nodes are visited
    while (remaining_nodes > 0) 
    {
      
        int u, min_dist = INF;  // Initializing variables for current node and minimum distance
        for (int v = 0; v < num_nodes; v++) {  // Finding node with minimum distance
            if (!visited[v] && dist[v] < min_dist) {  // Checking if node is not visited and distance is smaller than minimum
                min_dist = dist[v];  // Updating minimum distance
                u = v;  // Updating current node
            }
        }
        if (min_dist == INF)  // Checking if minimum distance is still infinity
            break;  // Exit loop

        visited[u] = 1;  // Mark current node as visited
        remaining_nodes--;  // Decrement remaining nodes
        // Checking if current node has outgoing edges
        if (graph[u].head != NULL) 
        {  
            struct Edge *current_edge = graph[u].head;  // Initializing pointer to first edge
            #pragma omp parallel for  // Parallelize loop
            for (int i = 0; i < num_nodes; i++) {  // Loop through all nodes
                int v = current_edge->destination;  // Getting destination of the edge
                int weight = current_edge->weight;  // Getting weight of the edge
                // Check if node is not visited and relaxation condition is satisfied
                if (!visited[v] && dist[u] != INF && dist[u] + weight < dist[v]) 
                {  
                    dist[v] = dist[u] + weight;  // Updating distance
                    parent[v] = u;  // Updating parent node
                    struct Path newPath = {v, dist[v]};  // Creating new path
                    insert(&paths[source], newPath);  // Inserting new path into priority queue
                }
                current_edge = current_edge->next;  // Move to next edge
            }
        }
    }

    printf("Process %d: Shortest paths from node %d:\n", rank, source);  // Printing header for shortest paths
    for (int i = 0; i < num_nodes; i++) {  // Loop through all nodes
        if (dist[i] == INF) {  // Checking if node is unreachable
            printf("Node %d is not reachable from node %d\n", i, source);  // Printing message for unreachable node
            continue;  // Skip to next node
        }
        printf("Top %d shortest path to Node %d:\n", K, i);  // Printing header for top K shortest paths to current node
        for (int j = 0; j < K && j < paths[i].size; j++) {  // Loop through top K shortest paths to current node
            printf("Distance = %d, Path: %d", paths[i].paths[j].distance, i);  // Printing distance and destination node
            int node = paths[i].paths[j].node;  // Getting parent node
            while (node != -1) {  // Repeat until parent node is invalid
                printf(" <- %d", node);  // Printing parent node
                node = parent[node];  // Updating parent node
            }
            printf("\n");  
        }
    }
    printf("\n"); 
}
// Function to find top K shortest paths
void findTopKShortestPaths(struct Node graph[], int num_nodes, int num_edges, int K, int rank) 
{  
    int size;  // Variable to store MPI size
    MPI_Comm_size(MPI_COMM_WORLD, &size);  // Getting number of processes

    int nodes_per_process = num_nodes / size;  // Calculating number of nodes per process
    int extra_nodes = num_nodes % size;  // Calculating number of extra nodes
    int start_node, end_node;  // Variables to store start and end nodes for current process

    if (rank < extra_nodes) {  // Checking if current process has extra nodes
        start_node = rank * (nodes_per_process + 1);  // Calculating start node index
        end_node = start_node + nodes_per_process;  // Calculating end node index
    } else {
        start_node = rank * nodes_per_process + extra_nodes;  // Calculating start node index
        end_node = start_node + nodes_per_process - 1;  // Calculating end node index
    }

    if (rank == size - 1) {  // Checking if current process is the last one
        end_node = num_nodes - 1;  // Set end node index to last node
    }
    // Allocate memory for priority queues
    struct PriorityQueue *paths = malloc(num_nodes * sizeof(struct PriorityQueue));  
    if (paths == NULL) {  // Check if memory allocation failed
        fprintf(stderr, "Memory allocation failed for paths\n"); 
        MPI_Finalize();  // Finalize MPI
        exit(1);
    }

    for (int i = 0; i < num_nodes; i++) {  // Initializing priority queues
        initPriorityQueue(&paths[i], K);  // Initializing priority queue for each node
    }

    #pragma omp parallel for  // Parallelize loop
    for (int source = start_node; source <= end_node; source++) {  // Loop through nodes assigned to current process
        dijkstra(source, num_nodes, graph, paths, K, rank);  // Performing Dijkstra's algorithm for each node
    }

    for (int i = 0; i < num_nodes; i++) {  // Free memory allocated for priority queues
        freePriorityQueue(&paths[i]);  // Free memory for each priority queue
    }
    free(paths);  // Free memory for array of priority queues
}

int main(int argc, char *argv[]) 
{  
    struct Node graph[MAX_NODES];  // Array to store graph nodes
    int num_nodes, num_edges;  // Variables to store number of nodes and edges

    int rank, size;  // Variables to store MPI rank and size
    MPI_Init(&argc, &argv);  // Initializing MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);  // Getting rank of current process
    MPI_Comm_size(MPI_COMM_WORLD, &size);  // Getting total number of processes

    double start_time, end_time;  // Variables to store start and end times
    double parallel_execution_time, sequential_execution_time;  // Variables to store execution times

    if (rank == 0) {  // Checking if current process is root
        if (!readGraphFromFile("graph.txt", graph, &num_nodes, &num_edges)) {  // Read graph from file
            MPI_Finalize();  // Finalize MPI
            return 1;  // Return failure status
        }
    }

    MPI_Bcast(&num_nodes, 1, MPI_INT, 0, MPI_COMM_WORLD);  // Broadcast number of nodes to all processes
    MPI_Bcast(&num_edges, 1, MPI_INT, 0, MPI_COMM_WORLD);  // Broadcast number of edges to all processes

    printf("Process %d: findTopKShortestPaths called with num_nodes %d and num_edges %d\n", rank, num_nodes, num_edges);   

    int K = 2;  // Set value of K for top K shortest paths

    // Measuring parallel execution time
    MPI_Barrier(MPI_COMM_WORLD);  // Synchronize all processes
    start_time = MPI_Wtime();  // Get start time
    findTopKShortestPaths(graph, num_nodes, num_edges, K, rank);  // Find top K shortest paths
    end_time = MPI_Wtime();  // Getting end time
    parallel_execution_time = end_time - start_time;  // Calculating parallel execution time

    // Gather execution times from all processes
    double* all_execution_times = NULL;  // Array to store execution times from all processes
    if (rank == 0) {  // Checking if current process is root
        all_execution_times = (double*)malloc(size * sizeof(double));  // Allocating memory for execution times
        // Check if memory allocation failed
        if (all_execution_times == NULL) 
        {  
            fprintf(stderr, "Memory allocation failed for all_execution_times\n"); 
            MPI_Finalize();  // Finalize MPI
            return 1;  // Return failure status
        }
    }
    // Gather parallel execution times
    MPI_Gather(&parallel_execution_time, 1, MPI_DOUBLE, all_execution_times, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);  
    // Checking if current process is root
    if (rank == 0) {  
        // Calculating total parallel execution time
        double total_parallel_time = 0.0;  // Variable to store total parallel execution time
        for (int i = 0; i < size; ++i) {  // Loop through all processes
            total_parallel_time += all_execution_times[i];  // Accumulating parallel execution times
        }

        // Calculating sequential execution time
        if (rank == 0) {  // Check if current process is root
            // Start timing for sequential execution
            start_time = MPI_Wtime();  // Get start time
            // Performing the same computation sequentially (without MPI)
            findTopKShortestPaths(graph, num_nodes, num_edges, K, rank);  // Finding top K shortest paths sequentially
            end_time = MPI_Wtime();  // Get end time
            sequential_execution_time = end_time - start_time;  // Calculating sequential execution time
        }

        // Output execution times
        printf("Total parallel execution time: %lf seconds\n", total_parallel_time);  
        if (rank == 0) {  // Check if current process is root
            printf("Sequential execution time: %lf seconds\n", sequential_execution_time); 
            // Calculate speedup
            double speedup = sequential_execution_time / total_parallel_time;  // Calculate speedup
            printf("Speedup: %lf\n", speedup);  
        }

        free(all_execution_times);  // Free memory allocated for execution times
    }

    MPI_Finalize();  // Finalize MPI

    return 0; 
}